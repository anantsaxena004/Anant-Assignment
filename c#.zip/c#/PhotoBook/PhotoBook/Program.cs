﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhotoBook
{
    internal class Program
    {
        public class PhotoBook
        {
            private int numPages;

            public int getNumbersPages()
            {
                return numPages;
            }

            public PhotoBook()
            {
                numPages = 16;
            }

            public PhotoBook(int pages)
            {
                this.numPages = pages;
            }
        }

        public class BigPhotoBook : PhotoBook
        {
           
            public BigPhotoBook() : base(64)
            {

            }
        }



        static void Main(string[] args)
        {
            PhotoBook defaultphotobook = new PhotoBook();
            Console.WriteLine("default pages are " + defaultphotobook.getNumbersPages());


            PhotoBook photobook = new PhotoBook(24);
            Console.WriteLine("photobook have " + photobook.getNumbersPages()+ " pages");


            BigPhotoBook largephotobook = new BigPhotoBook();
            Console.WriteLine("large photo book have " + largephotobook.getNumbersPages() + " pages");
            Console.ReadLine();

            

        }
    }
}