﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exc2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            List<(int key, string value)> rainbow = new List<(int, string)> 
            { 
                (2, "BLUE"), 
                (5, "ORANGE"), 
                (4, "YELLOW"), 
                (6, "RED"), 
                (3, "GREEN"), 
                (7, "WHITE"), 
                (1, "INDIGO"), 
                (0, "VIOLET") 
            };
            
            rainbow = rainbow.OrderBy(tuple => tuple.key).ToList();
            
            foreach ((int key, string value) i in rainbow)
            {
                Console.WriteLine(i.value);
            }

            Console.ReadKey();
        }
    
    }
}
