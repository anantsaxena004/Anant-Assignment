﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Dictionary
{

    internal class Program
    {
        
        static void Main(string[] args)
        {
            //operation 1
            Dictionary<int, string> players = new Dictionary<int, string>();

            //operation 2
            players.Add(1, "Player 5");
            players.Add(2, "Player 1");
            players.Add(3, "Player 3");
            players.Add(4, "Player 2");
            players.Add(5, "Player 4");

            //opeartion 3
            Console.WriteLine("Total numbers of players are: " + players.Count);

            Console.WriteLine("Before swap :- ");
            foreach (int i in players.Keys)
            {
                Console.WriteLine(players[i] + " got " + i + " position");
            }


            //operation 4
            /* string temperary = players[1];
             players[1] = players[5];
             players[5] = temperary*/

            (players[1], players[5]) = (players[5], players[1]);

            Console.WriteLine("After swap :- ");

            //operation 5
            foreach(int i in players.Keys)
            {
                Console.WriteLine( players[i] + " got " + i + " position" );
            }

            Console.ReadKey();
        
        }

    }
}
