﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Services;
using System.Text;
using System.Threading.Tasks;

namespace Task_09_04_
{
    internal class Program
    {
        static void evenSum()
        {
            int[] arr = new int[5];

            //taking input element from user
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine("Enter element " + i, arr[i]);
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
            int sum = 0;

            for (int i = 0; i < arr.Length; i++)
            {
                //checking if element is even or not
                if (arr[i] % 2 == 0)
                {
                    sum = sum + arr[i];
                }

            }
            Console.WriteLine("sum of even elements are " + sum);
            Console.ReadLine();
        }

        static void occCount()
        {
            Console.WriteLine("Enter a string:");
            string input = Console.ReadLine();

            int[] charCount = new int[256];

            foreach (char c in input)
            {
                charCount[c]++;
            }

            Console.WriteLine("Character counts:");
            for (int i = 0; i < charCount.Length; i++)
            {
                //if char count is more than 0 then it will print
                if (charCount[i] > 0)
                {
                    Console.WriteLine($"Character: {(char)i} - Count: {charCount[i]}");
                }
            }
            Console.ReadLine();
        }

        static void removeDuplicate()
        {
            Console.WriteLine("Enter a string:");
            string input = Console.ReadLine();

            string result = "";
            foreach (char c in input)
            {
                //this condtion checks if current char is present in string result
                if (!result.Contains(c))
                {
                    //if char is not present then it will push char to result
                    result += c;
                }
            }

            Console.WriteLine("String after removing duplicates:");
            Console.WriteLine(result);
            Console.ReadLine();
        }
        static void Main(string[] args)
        {
            //Q.1 write a program to total all the values that are even numbers of Given an array of ints.
            //evenSum();

            //Q2 Write a program to count the occurrence of each character in a string?
            occCount();

            //Q3.Write a program to remove duplicate characters from a string?
            //removeDuplicate();




        }
    }
}