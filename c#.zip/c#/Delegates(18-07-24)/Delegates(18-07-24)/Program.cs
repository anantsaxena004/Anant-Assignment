﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Delegates_18_07_24_.Program;

namespace Delegates_18_07_24_
{
    internal class Program
    {
        public delegate void voidDelegate();
        /*voidDelegate ob1 = print1;*/

        public delegate int delegateAdd(int x, int y);
        static void Main(string[] args)
        {
            delegateAdd del1 = sum;
            myclass.function2(del1);

            voidDelegate del = print1;
            myclass.function2(del);
        }

        private static void print1()
        {
            Console.WriteLine("Print 1");
            Console.ReadKey();
        }
        private static void print2()
        {
            Console.WriteLine("Print 2");
            Console.ReadKey();
        }

        private static int sum(int x, int y)
        {
            Console.WriteLine(x + y);
            return x + y;
        }
    }

    class myclass
    {
        public static void function2(voidDelegate del)
        {
            del();
            Console.ReadKey();


        }
    }
}
