﻿using System;

namespace Hello
{
    class program
    {
        static void Main(string[] args)
        {
            console.WriteLine("HELLO");
            console.Readline();
        }
    }
}
