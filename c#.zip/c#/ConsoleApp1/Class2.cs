﻿public class Program
{
    // Define a method that matches the delegate signature
    public static void Add(int a, int b)
    {
        Console.WriteLine($"Sum: {a + b}");
    }

    public static void Main()
    {
        // Create an instance of MyDelegate and associate it with the Add method
        MyDelegate myDelegate = new MyDelegate(Add);

        // Invoke the delegate (calls the Add method)
        myDelegate(3, 5); // Output: Sum: 8
    }
}
