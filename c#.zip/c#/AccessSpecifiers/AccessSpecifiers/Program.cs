﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Configuration;
using System.Text;
using System.Threading.Tasks;

namespace AccessSpecifiers
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Maruti swift = new Maruti();
            swift.model = "Swift";
            swift.color = "White";
            swift.price = 500000;
            swift.milage = 22.5f;
            swift.printCarInfo();
            swift.printMilage();
            Console.ReadLine();
        }

    }

    class Car 
    {
        protected internal string model;
             string color;
        public int price;

        public void printCarInfo()
        {
            Console.WriteLine("Mode is : " + model);
            Console.WriteLine("Color is : " + color);
            Console.WriteLine("Price is : " + price);
            
        }
    }


    class Maruti : Car
    {
        public float milage;
        

        public void printMilage()
        {
              
            Console.WriteLine("Milage is : " + milage);
            
        }


    }
}
