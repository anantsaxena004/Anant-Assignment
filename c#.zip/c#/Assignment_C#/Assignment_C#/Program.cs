﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_C_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Displaying a centered message using Console.SetCursorPosition
            string s = "ForeverEver Events: Crafting your perfect day, one detail at a time.";
            Console.SetCursorPosition((Console.WindowWidth - s.Length) / 2, Console.CursorTop);
            Console.WriteLine(s);

            string s2 = "Welcome to ForeverEver Events, where your dream wedding begins. Let's create memories that last forever.";
            Console.SetCursorPosition((Console.WindowWidth - s2.Length) / 2, Console.CursorTop);
            Console.WriteLine(s2);

            string s3 = "We have following plans";
            Console.SetCursorPosition((Console.WindowWidth - s3.Length) / 2, Console.CursorTop);
            Console.WriteLine(s3);

            // Displaying options for different plans
            string s4 = "Press 1 for plan 1 - Budget(Rs 10,00,000)";
            Console.SetCursorPosition((Console.WindowWidth - s4.Length) / 2, Console.CursorTop);
            Console.WriteLine(s4);

            string s5 = "Press 2 for plan 2 - Budget(Rs 20,00,000)";
            Console.SetCursorPosition((Console.WindowWidth - s5.Length) / 2, Console.CursorTop);
            Console.WriteLine(s5);

            string s6 = "Press 3 for plan 3 - Budget(Rs 25,00,000)";
            Console.SetCursorPosition((Console.WindowWidth - s6.Length) / 2, Console.CursorTop);
            Console.WriteLine(s6);

            string s7 = "Press 4 for Custom plan ";
            Console.SetCursorPosition((Console.WindowWidth - s7.Length) / 2, Console.CursorTop);
            Console.WriteLine(s7);

            int choice = Convert.ToInt32(Console.ReadLine());

            // Switch statement to execute different plans based on user input
            switch (choice)
            {
                case 1:
                    Plan1();
                    break;

                case 2:
                    Plan2();
                    break;

                case 3:
                    Plan3();
                    break;

                case 4:
                    CustomPlan();
                    break;

            }




            Console.ReadKey();
        }


        // Method to display Plan 1 details
        public static void Plan1()
        {
            string s4 = "Plan 1 , Budget - Rs 10,00,000 \n";
            Console.WriteLine(s4);



            Console.WriteLine("1.Entertainment - 1,00,000 ");
            Console.WriteLine("\t Band \n");

            Console.WriteLine("2. Catering - 3,50,000");
            Console.WriteLine("\t Food and Service \n");

            Console.WriteLine("3.Music - 80,000");
            Console.WriteLine("\t Ceremony Musicians / Orchestra \n");

            Console.WriteLine("4. Decoration - 2,00,000");
            Console.WriteLine("\t Reception Decorations and Centerpieces");
            Console.WriteLine("\t Ceremony Decorations");
            Console.WriteLine("\t Bride Bouquet");
            Console.WriteLine("\t Bridesmaid Bouquets");
            Console.WriteLine("\t Flower Girl Flowers \n");

            Console.WriteLine("5.Invitation - Rs 20,000");
            Console.WriteLine("\t Invitations and Reply Cards \t");



        }

        // Method to display Plan 2 details
        public static void Plan2()
        {
            // Displaying Plan 2 details
            string s4 = "Plan 2 , Budget - Rs 20,00,000 \n";
            Console.WriteLine("1.Entertainment - 1,60,000 ");
            Console.WriteLine("\t Band \n");

            Console.WriteLine("2. Beauty and Health - 1,00,000 ");
            Console.WriteLine("\t Hair and Makeup ");
            Console.WriteLine("\t Prewedding Pampering \n");

            Console.WriteLine("3. Music - 2,00,000");
            Console.WriteLine("\t Ceremony Musicians / Orchestra ");
            Console.WriteLine("\t DJ \n ");

            Console.WriteLine("4. Catering - 6,00,000");
            Console.WriteLine("\t Food and Service \n ");

            Console.WriteLine("5. Decoration - 3,00,000");
            Console.WriteLine("\t Reception Decorations and Centerpieces ");
            Console.WriteLine("\t Ceremony Decorations \n");

            Console.WriteLine("6. Rental - 1,60,000");
            Console.WriteLine("\t Reception Rentals \n");

            Console.WriteLine("7. Transportation - 60,000");
            Console.WriteLine("\t Guest Shuttle or Parking \n");

            Console.WriteLine("8. Invitation - 40,000");
            Console.WriteLine("\t Invitations and Reply Cards \n");

            Console.WriteLine("8. Venue - 3,80,000");
            Console.WriteLine("\t Ceremony Venue Fee ");
            Console.WriteLine("\t Reception Venue \n");

        }

        // Method to display Plan 3 details
        public static void Plan3()
        {
            // Displaying Plan 3 details
            string s4 = "Plan 3 , Budget - Rs 25,00,000 \n";
            Console.WriteLine("1.Entertainment -  2,00,000 ");
            Console.WriteLine("\t Band \n");

            Console.WriteLine("2. Beauty and Health - 1,25,000 ");
            Console.WriteLine("\t Hair and Makeup ");
            Console.WriteLine("\t Prewedding Pampering \n");

            Console.WriteLine("3. Music - 2,50,000");
            Console.WriteLine("\t Ceremony Musicians / Orchestra ");
            Console.WriteLine("\t Singer ");
            Console.WriteLine("\t DJ \n ");

            Console.WriteLine("4. Catering - 7,50,000");
            Console.WriteLine("\t Beverage and Bartenders ");
            Console.WriteLine("\t Food and Service \n ");

            Console.WriteLine("5. Decoration - 3,75,000");
            Console.WriteLine("\t Reception Decorations and Centerpieces ");
            Console.WriteLine("\t Groom and Groomsmen Boutonnieres ");
            Console.WriteLine("\t Flower Girl Flowers");
            Console.WriteLine("\t Ceremony Decorations \n");

            Console.WriteLine("6. Rental - 2,00,000");
            Console.WriteLine("\t Reception Rentals \n");

            Console.WriteLine("7. Transportation -  75,000");
            Console.WriteLine("\t Limo or Car Rentals");
            Console.WriteLine("\t Guest Shuttle or Parking \n");

            Console.WriteLine("8. Invitation - 50,000");
            Console.WriteLine("\t Invitations and Reply Cards \n");

            Console.WriteLine("8. Venue - 3,50,000");
            Console.WriteLine("\t Ceremony Venue Accessories ");
            Console.WriteLine("\t Ceremony Venue Fee ");
            Console.WriteLine("\t Rehearsal Dinner Venue ");
            Console.WriteLine("\t Reception Venue \n");

            Console.WriteLine("9. Fireworks - 1,25,000");
        }

        // Method to create a custom plan based on user input
        public static void CustomPlan()
        {
            int num_of_days;
            int num_of_person;
            int budget_per_plate;

            int total_amount = 0;

            Console.WriteLine("Do you want to add Entertainment to your plan? ");
            char eChoice; 
            eChoice = Console.ReadLine()[0];

            if (eChoice == 'y' )
            {
                Console.WriteLine("Entertainment - Band successfully added to your plan");
                total_amount = total_amount + 50000;
            }


            Console.WriteLine("Do you want to add Beauty and Health option");
            char beauty_choice;
            beauty_choice = Console.ReadLine()[0];
            if ( beauty_choice == 'y')
            {
                Console.WriteLine(" Hair, Makeup , Prewedding Pampering added to your plan");
                total_amount = total_amount + 20000;
            }

            Console.WriteLine("Do you want to add catering");
            char catering_choice;
            catering_choice = Console.ReadLine()[0];

            Console.WriteLine("For how many people do you wanna serve food");
            num_of_person = int.Parse(Console.ReadLine());

            Console.WriteLine("Your budget for on person plate");
            budget_per_plate = int.Parse(Console.ReadLine());

            if ( catering_choice == 'y')
            {
                Console.WriteLine("Services - Beverage and Bartenders , Food and Service added to your plan");
                total_amount = total_amount + num_of_person * budget_per_plate;
            }

            Console.WriteLine("Do you want to add musics to your plan");
            char musics_choice = Console.ReadLine()[0];
            if(musics_choice == 'y')
            {
                Console.WriteLine("Services - Ceremony Musicians / Orchestra , Singer, DJ added to your plan");
                total_amount = total_amount + 30000;
            }

            Console.WriteLine("Do you want to add decoration to your plan");
            char decor_choice = Console.ReadLine()[0];
            if (decor_choice == 'y')
            {
                Console.WriteLine("Services - Decoration added to your plan");
                total_amount = total_amount + 200000;
            }

            Console.WriteLine("Do you want to add invitation to your plan");
            char invitation_choice = Console.ReadLine()[0];
            if(invitation_choice == 'y')
            {
                Console.WriteLine("Services - Invitations and Reply Cards added to your plan");
                total_amount = total_amount + 20000;
            }

            Console.WriteLine("Do you want to add rental to your plan");
            char rental_choice = Console.ReadLine()[0];
            if(rental_choice == 'y')
            {
                Console.WriteLine("Service - rental added to your plan");
                total_amount = total_amount + 50000;
            }

            Console.WriteLine("Do you want to add Transportation facility to your plan");
            char transport_choice = Console.ReadLine()[0];
            if(transport_choice == 'y')
            {
                Console.WriteLine("Service - Guest Shuttle , Parking , Limo or Car Rentals added to your plan");
                total_amount = total_amount + 20000;
            }

            Console.WriteLine("Do you want to add venue to your plan");
            char venue_choice = Console.ReadLine()[0];
            Console.WriteLine("For how many days you want to book venue");
            num_of_days = int.Parse(Console.ReadLine());
            if(venue_choice == 'y')
            {
                Console.WriteLine("Service - Ceremony Venue Accessories,Ceremony Venue Fee,Rehearsal Dinner Venue added to your plan");
                total_amount = total_amount + num_of_days * 300000;
            }

            Console.WriteLine("Your total amount will be " + total_amount);

            Console.WriteLine("Thank you for choosing ForeverEver Events");

        }
    }
}
