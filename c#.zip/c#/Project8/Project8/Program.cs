﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project8
{
    internal class Program
    {
        static void evenSum()
        {
            string val = Console.ReadLine();
            int sum = 0;
            
            foreach (char c in val)
            {
                int a = int.Parse(val.ToString());
                if (a%2 == 0)
                {
                    sum = sum + a;
                }
                
            }
            Console.WriteLine(sum);


            Console.ReadLine();
        }
        static void Main(string[] args)
        {
            evenSum();

        }
    }
}
