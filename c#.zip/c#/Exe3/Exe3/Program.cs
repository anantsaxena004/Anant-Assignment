﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[] array = new double[6]; 
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = double.Parse(Console.ReadLine());
            }
            

            Console.WriteLine("Entered array is: ");

            for (int i = 0; i < array.Length; i++)
            {
                Console.WriteLine(array[i]);
            }

            Console.ReadKey();

            double countPositive = 0;
            double countNegative = 0;
            double countZero = 0;

            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] > 0)
                {
                    countPositive++;
                }
                else if (array[i] < 0)
                {
                    countNegative++;
                }
                else
                {
                    countZero++;
                }
            }

            



            Console.WriteLine("Ratio of positive elements are: " + countPositive / array.Length);
            Console.WriteLine("Ratio of negative elements are: " + countNegative / array.Length);
            Console.WriteLine("Ratio of zeros elements are: " + countZero / array.Length);
            Console.ReadKey();
        }
    }
}
