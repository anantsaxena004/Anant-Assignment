﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string val = Console.ReadLine();

            for (int i = 0; i < val.Length; i++)
            {
                int num = int.Parse(val);
            }
        }
    }
}
