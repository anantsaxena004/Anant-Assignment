﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Account
{
    internal class Program : BankAccount
    {
        static void Main(string[] args)
        {
            BankAccount b1 = new BankAccount();

            Console.WriteLine("Hello! " + b1.AccountHolderName);
            Console.WriteLine("Services at you Finger Tip");

            Console.WriteLine("Press 1 to know AccountNumber : ");

            Console.WriteLine("Press 2 to know Balance ");

            Console.WriteLine("Press 3 to know Bank Name ");

            Console.WriteLine("Press 4 to know InterestRate ");

            Console.WriteLine("Press 5 to know deposit money");

            Console.WriteLine("Press 6 to know withdraw money ");

            int choice = int.Parse((Console.ReadLine()));

            switch (choice)
            {
                case 1:
                    Console.WriteLine("Your Account Number is : " + b1.AccountNumber);
                    Console.ReadLine();
                    break;

                case 2:
                    Console.WriteLine("Your current Balance is : " + b1.Balance);
                    Console.ReadLine();
                    break;

                case 3:
                    Console.WriteLine("Your Bank name is : " + b1.BankName);
                    Console.ReadLine();
                    break;

                case 4:
                    Console.WriteLine("Your interest rate is : " + b1.InterestRate);
                    Console.ReadLine();
                    break;

                case 5: 
                    Console.WriteLine("Enter amount to be deposited");
                    int a = int.Parse((Console.ReadLine()));
                    b1.Deposit(a);
                    break;

                case 6:
                    Console.WriteLine("Enter amount to be withdrawn");
                    int b = int.Parse((Console.ReadLine()));
                    b1.Withdraw(b);
                    break;

                default:
                    Console.WriteLine("PLEASE ENTER A VAILD RESPONSE");
                    Console.ReadLine();
                    break;

            }


        }
    }

    class BankAccount
    {
        protected internal int AccountNumber;
        public string AccountHolderName;
        internal int Balance;


        protected internal string BankName;

        public double InterestRate;

        private List<string> Transactions;

        public BankAccount()
        {
            Console.WriteLine("Enter AccountNumber : ");
            AccountNumber  = int.Parse(Console.ReadLine());
           
            Console.WriteLine("Enter Account Holder Name : ");
            AccountHolderName = Console.ReadLine();

            Console.WriteLine("Balance : ");
            Balance = int.Parse(Console.ReadLine());

            Console.WriteLine("BankName : ");
            BankName = Console.ReadLine();

            Console.WriteLine("InterestRate : ");
            InterestRate = double.Parse(Console.ReadLine());

            /*Console.WriteLine("Transactions : ");
            Transactions = Console.ReadLine();*/

        }

        public void Deposit(int amount)
        {
            if(amount > 0)
            {
                Balance = Balance + amount;
                Console.WriteLine("Amount deposited successfully");
                Console.WriteLine("Your current balance is " + Balance);
                Console.ReadLine();
            }

            else
            {
                Console.WriteLine("Enter a vaild amount");
                Console.ReadLine();
            }
        }

        public void Withdraw(int  amount)
        {
            if (Balance > 0)
            {
                Balance = Balance - amount;
                Console.WriteLine("Amount withdrawn successfully");
                Console.WriteLine("Your current balance is " + Balance);
                Console.ReadLine();
            }
            else
            {
                Console.WriteLine("Insufficient Balance ");
                Console.ReadLine();
            }
        }

        public void AddTranscation(string transcationDetails)
        {
            Transactions.Add(transcationDetails);
        }

    }


    
}
