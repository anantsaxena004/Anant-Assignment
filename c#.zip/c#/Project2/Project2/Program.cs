﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your age:");
            string age = Console.ReadLine();

            if(int.TryParse(age,out int age1))
            {
                if (age1 >= 18)
                {
                    Console.WriteLine("Congratulation! You are eligible for casting your vote. ");
                    Console.ReadLine();
                }
                else
                {
                    Console.WriteLine("You  are not eligible  for  casting  your  vote.");
                    Console.ReadLine();
                }
            }
        }
    }
}
