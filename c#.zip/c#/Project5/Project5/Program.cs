﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int ang1,ang2,ang3;
            Console.WriteLine("Enter different angles");

            string[] values = Console.ReadLine().Split();

            if (values.Length == 3)
            {
                ang1 = int.Parse(values[0]);
                ang2 = int.Parse(values[1]);
                ang3 = int.Parse(values[2]);

                int sum = ang1 + ang2 + ang3;

                if (sum == 180)
                {
                    Console.WriteLine("The triangle is valid.");
                }
                else
                {
                    Console.WriteLine("The triangle is not valid.");
                }
            }
    }
}
