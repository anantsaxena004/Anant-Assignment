﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int rollNumber,phyMarks, chemMarks,compMarks;

            Console.WriteLine("Enter roll number");
            rollNumber = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter name of student");
            string name = Console.ReadLine();

            Console.WriteLine("Enter marks of Physics");
            phyMarks = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter marks of Chemistry");
            chemMarks = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter marks of Computer application");
            compMarks = Convert.ToInt32(Console.ReadLine());

            int totalMarks = phyMarks+chemMarks+compMarks;

            Console.WriteLine("Total marks of student is " + totalMarks);
            Console.ReadLine();

            double percent = ((double)totalMarks / 300) * 100;

            Console.WriteLine("Percentage obtained is " + percent);
            Console.ReadLine();

            if (percent > 60)
            {
                Console.WriteLine("First devision");
                
            }

            Console.ReadLine();


        }
    }
}
